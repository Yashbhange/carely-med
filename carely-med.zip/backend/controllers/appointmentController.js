import Appointment from "../models/Appointment.js";

export const createAppointment = async (req,res)=>{
  try {
    const data = await Appointment.create(req.body);
    res.status(201).json(data);
  } catch(err) {
    res.status(500).json({message: err.message});
  }
};
