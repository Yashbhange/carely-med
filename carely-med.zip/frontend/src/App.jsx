import { useState } from "react";
import axios from "axios";

export default function App() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    doctor: "",
    date: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/appointments", form);
    alert("Booked!");
  };

  return (
    <div style={{padding:20}}>
      <h1>Carely Med Hospital</h1>

      <form onSubmit={submit}>
        <input name="name" placeholder="Name" onChange={handleChange} /><br/>
        <input name="email" placeholder="Email" onChange={handleChange} /><br/>
        <input name="doctor" placeholder="Doctor" onChange={handleChange} /><br/>
        <input name="date" type="date" onChange={handleChange} /><br/>
        <button>Book</button>
      </form>
    </div>
  );
}
