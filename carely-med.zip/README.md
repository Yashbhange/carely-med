# Carely Med Hospital Project

## Run Backend
cd backend
npm install
npm run dev

## Run Frontend
cd frontend
npm install
npm run dev
